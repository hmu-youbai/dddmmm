def quchongfa(r1name,r2name):
    num = 0
    r1 = []
    with open(r1name, 'r') as file1:
        for line in file1:
            num = num + 1
            if (num % 4) == 2:
                r1.append(line.strip())
    file1.close()
    num = 0
    r2 = []
    with open(r2name, 'r') as file2:
        for line in file2:
            num = num + 1
            if (num % 4) == 2:
                r2.append(line.strip())
    file2.close()

    cc1 = []
    for i in range(len(r1)):
        cc1.append(r1[i] + " " + r2[i])
    cc2 = list(set(cc1))

    jieguo="r1r2set"
    with open(jieguo, 'w') as file3:
        for i in range(len(cc2)):
            print("name" + str(i) + " " + cc2[i].split()[0] + " " + cc2[i].split()[1], file=file3)
    file3.close()

    out_file = "r1.fa"
    fin = open(jieguo, 'r')
    fout = open(out_file, 'w')
    i = 0
    for line in fin:
        line = line.strip()
        eles = line.split()
        r1_seq = eles[0]
        r2_seq = eles[1]
        print('%s%d%s%s' % (">", i, "_", r1_seq), file=fout)
        print('%s' % (r2_seq), file=fout)
        i += 1
    fin.close()
    fout.close()

    out_file = "r2.fa"
    fin = open(jieguo, 'r')
    fout = open(out_file, 'w')
    i = 0
    for line in fin:
        line = line.strip()
        eles = line.split()
        r1_seq = eles[0]
        r2_seq = eles[2]
        print('%s%d%s%s' % (">", i, "_", r1_seq), file=fout)
        print('%s' % (r2_seq), file=fout)
        i += 1
    fin.close()
    fout.close()


def quchongr1(r1name):
    num = 0
    r1 = []
    with open(r1name, 'r') as file1:
        for line in file1:
            num = num + 1
            if (num % 4) == 2:
                r1.append(line.strip())
    file1.close()
    return r1
def quchongr2(r2name):
    num = 0
    r2 = []
    with open(r2name, 'r') as file2:
        for line in file2:
            num = num + 1
            if (num % 4) == 2:
                r2.append(line.strip())
    file2.close()
    return r2
def quchongset(r1,r2):
    cc1 = []
    for i in range(len(r1)):
        cc1.append(r1[i] + " " + r2[i])
    cc2 = list(set(cc1))
    jieguo="r1r2set"
    with open(jieguo, 'w') as file3:
        for i in range(len(cc2)):
            print("name" + str(i) + " " + cc2[i].split()[0] + " " + cc2[i].split()[1], file=file3)
    file3.close()
    return len(cc2)

def quchongw1():
    out_file = "r1.fa"
    fin = open("r1r2set", 'r')
    fout = open(out_file, 'w')
    i = 0
    for line in fin:
        line = line.strip()
        eles = line.split()
        r1_seq = eles[0]
        r2_seq = eles[1]
        print('%s%d%s%s' % (">", i, "_", r1_seq), file=fout)
        print('%s' % (r2_seq), file=fout)
        i += 1
    fin.close()
    fout.close()

def quchongw2():
    out_file = "r2.fa"
    fin = open("r1r2set", 'r')
    fout = open(out_file, 'w')
    i = 0
    for line in fin:
        line = line.strip()
        eles = line.split()
        r1_seq = eles[0]
        r2_seq = eles[2]
        print('%s%d%s%s' % (">", i, "_", r1_seq), file=fout)
        print('%s' % (r2_seq), file=fout)
        i += 1
    fin.close()
    fout.close()