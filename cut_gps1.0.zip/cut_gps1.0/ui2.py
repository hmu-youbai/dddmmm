# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ui2.ui'
##
## Created by: Qt User Interface Compiler version 6.4.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QPushButton, QSizePolicy, QTextBrowser,
    QWidget)

class Ui_tran1_2(object):
    def setupUi(self, tran1_2):
        if not tran1_2.objectName():
            tran1_2.setObjectName(u"tran1_2")
        tran1_2.resize(921, 635)
        self.showme = QTextBrowser(tran1_2)
        self.showme.setObjectName(u"showme")
        self.showme.setGeometry(QRect(70, 50, 761, 331))
        self.tran1 = QPushButton(tran1_2)
        self.tran1.setObjectName(u"tran1")
        self.tran1.setGeometry(QRect(70, 440, 91, 51))
        self.tran2 = QPushButton(tran1_2)
        self.tran2.setObjectName(u"tran2")
        self.tran2.setGeometry(QRect(70, 510, 91, 51))
        self.tishi = QPushButton(tran1_2)
        self.tishi.setObjectName(u"tishi")
        self.tishi.setGeometry(QRect(190, 440, 91, 51))
        self.pushButton = QPushButton(tran1_2)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setGeometry(QRect(820, 440, 75, 24))
        self.pushr1 = QPushButton(tran1_2)
        self.pushr1.setObjectName(u"pushr1")
        self.pushr1.setGeometry(QRect(300, 500, 91, 51))
        self.zhijieqie = QPushButton(tran1_2)
        self.zhijieqie.setObjectName(u"zhijieqie")
        self.zhijieqie.setGeometry(QRect(410, 500, 91, 51))

        self.retranslateUi(tran1_2)
        self.pushButton.clicked.connect(self.showme.clear)

        QMetaObject.connectSlotsByName(tran1_2)
    # setupUi

    def retranslateUi(self, tran1_2):
        tran1_2.setWindowTitle(QCoreApplication.translate("tran1_2", u"Form", None))
        self.tran1.setText(QCoreApplication.translate("tran1_2", u"fa\u8f6cfq", None))
        self.tran2.setText(QCoreApplication.translate("tran1_2", u"fq\u8f6cfa", None))
        self.tishi.setText(QCoreApplication.translate("tran1_2", u"\u7ed9\u5927\u5bb6\u6574\u4e2a\u6d3b", None))
        self.pushButton.setText(QCoreApplication.translate("tran1_2", u"all clear", None))
        self.pushr1.setText(QCoreApplication.translate("tran1_2", u"\u53cc\u7aef\u53bb\u91cd", None))
        self.zhijieqie.setText(QCoreApplication.translate("tran1_2", u"\u5207\u8fb9\u754c", None))
    # retranslateUi

